package com.example.parenteapp.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.parenteapp.R;

import java.util.ArrayList;

/**
 * A placeholder fragment containing a simple view.
 */
public class PlaceholderFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "section_number";

    private PageViewModel pageViewModel;
    private int section;
    private ArrayList<Persona> peopleList;
    private ArrayList<Call> callList;
    private ListView listView;

    public static PlaceholderFragment newInstance(int index) {
        PlaceholderFragment fragment = new PlaceholderFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ARG_SECTION_NUMBER, index);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pageViewModel = new ViewModelProvider(this).get(PageViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            index = getArguments().getInt(ARG_SECTION_NUMBER);
        }
        pageViewModel.setIndex(index);
        section = index;
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        /*
        View root = inflater.inflate(R.layout.fragment_main, container, false);
        final TextView textView = root.findViewById(R.id.section_label);
        pageViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;*/
        View fragmentLayout = inflater.inflate(R.layout.fragment_main_persone, container, false);

        //initializing objects
        if(section == 1) {
            peopleList = new ArrayList<>();
            listView = (ListView) fragmentLayout.findViewById(R.id.mylistview);

            //adding some values to our list
            peopleList.add(new Persona(R.drawable.tina, "Tina", "Zia"));
            peopleList.add(new Persona(R.drawable.anna, "Anna", "Sorella"));
            peopleList.add(new Persona(R.drawable.michela, "Michela", "Figlia"));
            peopleList.add(new Persona(R.drawable.ezio, "Ezio", "Fratellastro"));
            peopleList.add(new Persona(R.drawable.tonio, "Tonio", "Marito"));
            peopleList.add(new Persona(R.drawable.nicola, "Nicola", "Figlio"));

            //creating the adapter
            PeopleListAdapter adapter = new PeopleListAdapter(getActivity(), R.layout.custom_list, peopleList);

            //attaching adapter to the listview
            listView.setAdapter(adapter);
        }

        if(section == 2)
        {
            callList = new ArrayList<>();
            listView = (ListView) fragmentLayout.findViewById(R.id.mylistview);

            //adding some values to our list
            callList.add(new Call(new Persona(R.drawable.tina, "Tina", "Zia"), new Persona(R.drawable.tina, "Michele", "Figlio"), 0));
            callList.get(callList.size()-1).setCalltime(1000);

            callList.add(new Call(new Persona(R.drawable.tina, "Mina", "Zia"), new Persona(R.drawable.tina, "Michele", "Figlio"), 1));
            callList.get(callList.size()-1).setCalltime(500);

            callList.add(new Call(new Persona(R.drawable.tina, "Nicola", "Zia"), new Persona(R.drawable.tina, "Michele", "Figlio"), 2));
            callList.get(callList.size()-1).setCalltime(100000);

            CallListAdapter adapter = new CallListAdapter(getActivity(), R.layout.cronologia, callList);

            //attaching adapter to the listview
            listView.setAdapter(adapter);
        }

    /*
        ListView listView1 = (ListView) fragmentLayout.findViewById(R.id.mylistview);
        String [] array = {"Antonio","Giovanni","Michele","Giuseppe", "Leonardo", "Alessandro"};
        ArrayAdapter adapter = new ArrayAdapter<String>(getActivity(), R.layout.list_item, array);
        listView1.setAdapter(adapter);*/

        return fragmentLayout;
    }
}


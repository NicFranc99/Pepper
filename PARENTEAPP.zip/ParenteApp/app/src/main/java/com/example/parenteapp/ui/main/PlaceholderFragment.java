package com.example.parenteapp.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.parenteapp.R;

import java.util.ArrayList;

/**
 * A placeholder fragment containing a simple view.
 */
public class PlaceholderFragment extends Fragment {

    private static final String ARG_SECTION_NUMBER = "section_number";

    private PageViewModel pageViewModel;
    private ArrayList<Hero> heroList;
    private ListView listView;

    public static PlaceholderFragment newInstance(int index) {
        PlaceholderFragment fragment = new PlaceholderFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(ARG_SECTION_NUMBER, index);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pageViewModel = new ViewModelProvider(this).get(PageViewModel.class);
        int index = 1;
        if (getArguments() != null) {
            index = getArguments().getInt(ARG_SECTION_NUMBER);
        }
        pageViewModel.setIndex(index);
    }

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        /*
        View root = inflater.inflate(R.layout.fragment_main, container, false);
        final TextView textView = root.findViewById(R.id.section_label);
        pageViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;*/
        View fragmentLayout = inflater.inflate(R.layout.fragment_main, container, false);

        //initializing objects
        heroList = new ArrayList<>();
        listView = (ListView) fragmentLayout.findViewById(R.id.mylistview);

        //adding some values to our list
        heroList.add(new Hero(R.drawable.tina, "Tina", "Zia"));
        heroList.add(new Hero(R.drawable.anna, "Anna", "Sorella"));
        heroList.add(new Hero(R.drawable.michela, "Michela", "Figlia"));
        heroList.add(new Hero(R.drawable.ezio, "Ezio", "Fratellastro"));
        heroList.add(new Hero(R.drawable.tonio, "Tonio", "Marito"));
        heroList.add(new Hero(R.drawable.nicola, "Nicola", "Figlio"));

        //creating the adapter
        MyListAdapter adapter = new MyListAdapter(getActivity(), R.layout.custom_list, heroList);

        //attaching adapter to the listview
        listView.setAdapter(adapter);
    /*
        ListView listView1 = (ListView) fragmentLayout.findViewById(R.id.mylistview);
        String [] array = {"Antonio","Giovanni","Michele","Giuseppe", "Leonardo", "Alessandro"};
        ArrayAdapter adapter = new ArrayAdapter<String>(getActivity(), R.layout.list_item, array);
        listView1.setAdapter(adapter);*/

        return fragmentLayout;
    }
}


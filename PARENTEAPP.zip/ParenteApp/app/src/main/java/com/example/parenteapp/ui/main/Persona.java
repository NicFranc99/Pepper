package com.example.parenteapp.ui.main;

public class Persona {

    private int image;
    private String name;
    private String status;

    public Persona(int image, String name, String status) {
        this.image = image;
        this.name = name;
        this.status = status;
    }

    public int getImage() {
        return image;
    }

    public String getName() {
        return name;
    }

    public String getStatus() {
        return status;
    }
}